document.addEventListener('dblclick', function(event) {
    let selectedText = window.getSelection().toString().trim();
    if (selectedText) {
        fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${selectedText}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Error fetching definition for: ${selectedText}`);
                }
                return response.json();
            })
            .then(data => {
                let definition = data[0].meanings[0].definitions[0].definition;
                showTooltip(event, selectedText, definition);
            })
            .catch(error => {
                console.error(`Error: ${error.message}`);
            });
    }
});

function showTooltip(event, word, definition) {
    removeTooltip();

    let tooltip = document.createElement('div');
    tooltip.className = 'definition-tooltip';
    tooltip.innerHTML = `<strong>${word}</strong>: ${definition}`;
    tooltip.style.position = 'absolute';
    tooltip.style.backgroundColor = '#333';
    tooltip.style.color = '#fff';
    tooltip.style.borderRadius = '8px';
    tooltip.style.padding = '10px';
    tooltip.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
    tooltip.style.fontSize = '14px';
    tooltip.style.zIndex = '1000';

    document.body.appendChild(tooltip);

    let tooltipWidth = tooltip.offsetWidth;
    let tooltipHeight = tooltip.offsetHeight;
    let posX = event.pageX + 10;
    let posY = event.pageY + 10;

    if ((posX + tooltipWidth) > window.innerWidth) {
        posX = window.innerWidth - tooltipWidth - 10;
    }
    if ((posY + tooltipHeight) > window.innerHeight) {
        posY = window.innerHeight - tooltipHeight - 10;
    }

    tooltip.style.left = `${posX}px`;
    tooltip.style.top = `${posY}px`;

    document.addEventListener('selectionchange', removeTooltip);
}

function removeTooltip() {
    let existingTooltip = document.querySelector('.definition-tooltip');
    if (existingTooltip) {
        existingTooltip.remove();
    }
}
